import serial.tools.list_ports
serial.tools.list_ports.main()